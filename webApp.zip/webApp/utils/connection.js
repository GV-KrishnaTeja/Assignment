const mysql      = require('mysql');

const connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'Password@123',
  database : 'assignment'
});

connection.connect(function(error){
    if(error) throw error
    else console.log("connected!!!!")
})
