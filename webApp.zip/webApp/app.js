var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
const bodyParser = require('body-parser');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
//const gbooksPage = require('./routes/gbooks')
const login = require('./routes/login')
const welcomePath=require('./routes/login')
const regformPath = require('./routes/reg-form-check')
const bookPath = require('./routes/curdOp');
const books_dumb = require('./src/books_dumb');
var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.get ('/login',login)
app.post('/welcome',welcomePath)
app.post('/reg-form',regformPath)
app.get('/reg-form',regformPath)
app.get('/books',bookPath);
app.get('/books/:id',bookPath);
app.post('/books',bookPath);
app.put('/books/:id',bookPath)
app.delete('/books/:id',bookPath)
app.get('/books/:cn',bookPath)

//app.get('/gbooks',gbooksPage)

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
