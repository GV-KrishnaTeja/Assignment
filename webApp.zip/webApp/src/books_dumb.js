module.exports = [
    {
        "title": "Unlocking Android: A Developer's Guide",
        "isbn": "1933988673",
        "pageCount": 416,
        "numberofbooks":1
      
    },
    {
        "title": "Flex 3 in Action",
        "isbn": "1933988746",
        "pageCount": 576,
        "numberofbooks":20
    },
    {
     
        "title": "Flex 4 in Action",
        "isbn": "1935182420",
        "pageCount": 600,
        "numberofbooks":0
    },
    {
        "title": "Collective Intelligence in Action",
        "isbn": "1933988312",
        "pageCount": 425,
        "numberofbooks":0    
    },
    {
        "title": "Zend Framework in Action",
        "isbn": "1933988320",
        "pageCount": 432,
        "numberofbooks":12
        
    },
    {
        "title": "Flex on Java",
        "isbn": "1933988797",
        "pageCount": 265,
        "numberofbooks":2
        
    },
    {
        "title": "Griffon in Action",
        "isbn": "1935182234",
        "pageCount": 375,
        "numberofbooks":10
        
    },
    {
        "title": "OSGi in Depth",
        "isbn": "193518217X",
        "pageCount": 325,
        "numberofbooks":21
    }
]
