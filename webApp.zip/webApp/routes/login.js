const express = require('express');
const path = require('path');
var router = express.Router();
const connection =require('../utils/connection')
router.get('/login', function(req, res, next) {
  
    res.render('login', { title: 'Express' });
});

router.post('/welcome',function(req,res,next){
    res.render('welcome')
})

module.exports = router;
