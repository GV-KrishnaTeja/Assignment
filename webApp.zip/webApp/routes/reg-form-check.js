var express = require("express");
var router = express.Router();
const connection = require("../utils/connection");


router.get('/reg-form',(req,res,next) =>{
  const fname = req.body.fname ; 
  const lname = req.body.lname;
  //console.log(fname,lname);
  
    
    res.render('reg-form');
})


router.post("/reg-form-check", (req, res, next) => {
  const Id = req.body.Id;
  const fname = req.body.fname;
  const lname = req.body.lname;
  const email = req.body.email;
  const password = req.body.password;
  const gender = req.body.gender;




  //insert into db:
  
  try {
     connection.query(
      `INSERT INTO newlogin (Id,fname,lname,email,gender,password )
             VALUES
              ( '${Id}', '${fname}' ,'${lname}','${email}','${gender}','${password}')`,
      (error, results) => {
        if (error) {
          return res.send(error);
        } else {
          console.log(results)
          res.send('created new user ')
        }
        //   const datesObj = {dates:[]};
        //   connection.query(`insert into attendance values ('${email}','${time}',0,'${JSON.stringify(datesObj)}')`,(error,result)=>{
        //     if(error) return console.log(error);

        //       console.log('result of attendance:',result);


        //res.send('welcome')
        //   connection.query(
        //     `select * from studentdata where email = '${email}'`,
        //     (error, result) => {
        //       if (error) {
        //         console.log("Unable to find results!");
        //       }
        //       res.render("studentData", { result });
        //     }
        //   );
        //res.send('<h1>Data inserted successfully!</h1>')
        //res.render('studentData',{})
      }
    );




    //res.render('reg-form');
  } catch (e) {
    console.log(e);
  }
});

module.exports = router;