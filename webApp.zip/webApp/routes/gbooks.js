// var books = require('google-books-search');
// var express = require('express');
// var router = express.Router();


// router.get('/gbooks', function(req, res, next) {
//     books.search('Professional JavaScript for Web Developers', function(error, results) {
//         if ( ! error ) {
//             console.log(results);
//         } else {
//             console.log(error);
//         }
//     });
//     res.send(['gbooks']);
//   });
  
// module.exports = router;
  
